from artar_fe.guardrails import validate_tool


def test_guardrails_accepts_noop_tool():
    validate_tool("noop_tool")
