Verification prompt placeholder.
