Reporting prompt placeholder.
