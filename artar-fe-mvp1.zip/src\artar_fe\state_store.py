def init_state() -> dict:
    return {
        "history": [],
        "self_correction_used": False,
    }
