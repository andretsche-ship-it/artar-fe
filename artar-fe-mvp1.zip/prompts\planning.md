Planning prompt placeholder.
