System prompt placeholder.
