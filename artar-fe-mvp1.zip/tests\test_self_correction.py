from pathlib import Path
from artar_fe.orchestrator import run_case


def test_run_case_creates_report_dict(tmp_path: Path):
    report = run_case(tmp_path / "case", tmp_path / "out")
    assert "findings" in report
